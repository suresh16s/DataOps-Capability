use Row_Transformation;
select * from [dbo].[DerivedCul];